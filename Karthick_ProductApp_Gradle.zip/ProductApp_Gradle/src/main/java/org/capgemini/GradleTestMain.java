/**
 * 
 */
package org.capgemini;

/**
 * @author kkannaiy
 *
 */
public class GradleTestMain {
	public static void main(String[] args) {
        System.out.println("Hello to Gradle Labs!"); // Display the string.
    }
}
